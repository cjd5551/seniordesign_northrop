﻿using System;
using System.Net;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace SD_ConnectionTesting
{
    class Program
    {
        private static UdpClient udp;

        static void Main(string[] args)
        {
            LaunchCommandLineApp();
        } // end main()

        static void LaunchCommandLineApp()
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "bsc.exe";
            startInfo.WindowStyle = ProcessWindowStyle.Normal;
            startInfo.Arguments = "127.0.0.1 52020 52021";

            try {
                using (Process exeProcess = Process.Start(startInfo)) {
                    Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                    IPAddress serverAddr = IPAddress.Parse("127.0.0.1");
                    IPEndPoint endPoint = new IPEndPoint(serverAddr, 52020);
                    BattleShortCmd bsc = new BattleShortCmd();
                    sock.SendTo(bsc.getCMD(), bsc.getCMD().Length, SocketFlags.None, endPoint);
                    udp = new UdpClient(52021);
                    udp.BeginReceive(DataReceived, new object());
                    exeProcess.WaitForExit();
                } // end using
            } catch {
                System.Console.WriteLine("Error in starting file process.");
            } // end try-catch
            
        } // end LaunchCommandLineApp()

        private static void DataReceived(IAsyncResult ar)
        {
            System.Console.WriteLine("Waiting to receive...");
            IPAddress serverAddr = IPAddress.Parse("127.0.0.1");
            IPEndPoint ip = new IPEndPoint(serverAddr, 52021);
            byte[] bytes = udp.EndReceive(ar, ref ip);
            string message = Encoding.ASCII.GetString(bytes);
            Console.WriteLine(message);
        }
    }
}
